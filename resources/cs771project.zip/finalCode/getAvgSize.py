import cv2
import os, glob
from skimage.io import imread,imsave,imshow,show
from operator import itemgetter, attrgetter
from skvideo.io import VideoCapture

'''
make a directory and update dirPose with its name to store images in that folder
change the paramenter of line 14 and line 23 with the fileName of the video
update line 37 with the feature to extract
'''

dimList = {}

dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle', 'Number-plate', 'Autorickshaw', 'Rickshaw']

for x in dirPosList:
	dimList[x] = None

dirPos = "imageData"

if not os.path.exists(dirPos):
	os.makedirs(dirPos)

for x in dirPosList:
	if not os.path.exists(dirPos + '/' + x):
		os.makedirs(dirPos + '/' + x)

for obj in dirPosList:

	avgX = 0
	avgY = 0
	avgR = 0

	fileList = list(glob.glob(dirPos + '/' + obj + '/*.jpg'))

	for img in fileList:
		tmpImg = imread(img)
		avgX += tmpImg.shape[0]
		avgY += tmpImg.shape[1]
		avgR += (tmpImg.shape[0]*(1.0))/(tmpImg.shape[1]*(1.0))
		# imshow(tmpImg)
		# show()

	avgX, avgY, avgR = avgX/(len(fileList)*1.0), avgY/(len(fileList)*1.0), avgR/(len(fileList)*1.0)

	dimList[obj] = (avgX, avgY, avgR)

print dimList