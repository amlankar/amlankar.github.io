import sys,os
from skimage.io import imread,imsave,imshow,show
from skimage.transform import resize
import pickle
import random
import skimage
from skimage.feature import hog
from numpy import zeros, uint8
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
import sklearn
import os, struct
from array import array as pyarray
from numpy import append, array, int8
from sklearn.svm import LinearSVC, SVC
from sklearn.decomposition import PCA
from sklearn.externals import joblib

sizeDim = 100
split = (0.8)

# dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle', 'Number-plate', 'Autorickshaw', 'Rickshaw']
dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle', 'Autorickshaw', 'Rickshaw']
# dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle']
# dirPosList = ['Car', 'Person']

def resizer(img, dim = 100):
	return resize(img, (dim, dim))

def translate(img, dim = 100, ratio = 0.85):
	ans = []
	r, c = int(img.shape[0]), int(img.shape[1])
	tr, tc = int(ratio*r), int(ratio*c)
	ans.append(img[:r,:c])
	ans.append(img[:r,c-tc:])
	ans.append(img[r-tr:,:c])
	ans.append(img[r-tr:,c-tc:])
	a = map(resizer, ans)
	# print len(a), len(a[0]), len(a[0][0])
	return a

def encode(val):
	return dirPosList.index(val)

def transformLabel(Y, target):
	Y[Y != target] = -1
	Y[Y == target] = 1
	return Y

def convertLabel(Y, initVal, finalVal):
	# Transform initVal to finalVal
	Y[Y == initVal] = finalVal
	return Y

# fetList = {}
# trainSet = []
# testSet = []

# for x in dirPosList:
# 	fetList[x] = [[], []]
# 	fetList[x][0] = []			# Train data
# 	fetList[x][0] = []			# Test data

# for obj in dirPosList:

# 	folder = 'imageData/' + obj +'/resized' + obj + '/'	
# 	print folder
# 	fileList = sorted(os.listdir(folder))
# 	trainLen = int(split*(len(fileList)))
	
# 	for i in range(len(fileList)):
# 		filename = fileList[i]

# 		numImg = filename.split('_')[1]
# 		numImg = numImg.split('.')[0]
# 		numImg = int(numImg)

# 		if (numImg%4 != 3):
# 			continue

# 		img = imread(folder + filename)

# 		if ((img.shape[0] < sizeDim) or (img.shape[1] < sizeDim)):
# 			continue

# 		tmpImg = resize(img, (sizeDim, sizeDim))
# 		tmpImg = skimage.color.rgb2gray(tmpImg)
# 		# tmpImg = img 	# Do not resize, for HOG features
# 		# tmpList = np.array(tmpImg.flatten(), dtype = np.float16)

# 		tmpList = np.array(tmpImg, dtype = np.float16)

# 		transList = translate(tmpList)
# 		transList.extend(translate(tmpList[:,::-1]))

# 		# print len(transList), len(transList[0])

# 		# if (i < trainLen):
# 		# 	fetList[obj][0].append(tmpList)
# 		# 	fetList[obj][0].append(tmpList[:,::-1])
# 		# 	trainSet.append(filename)
# 		# else:
# 		# 	fetList[obj][1].append(tmpList)			
# 		# 	fetList[obj][1].append(tmpList[:,::-1])
# 		# 	testSet.append(filename)

# 		if (i < trainLen):
# 			fetList[obj][0].extend(transList)
# 			trainSet.append(filename)
# 		else:
# 			fetList[obj][1].extend(transList)			
# 			testSet.append(filename)

# # print testSet
# # print trainSet

# 		# imshow(tmpImg)
# 		# show()

# X = []
# Y = []
# testX = []
# testY = []

# for x in dirPosList:
# 	X.extend(fetList[x][0])
# 	Y.extend([x]*len(fetList[x][0]))
# 	testX.extend(fetList[x][1])
# 	testY.extend([x]*len(fetList[x][1]))

# tmp = zip(X,Y)
# random.shuffle(tmp)
# # random.shuffle(tmp)
# X, Y = zip(*tmp)

# X = np.array(X)
# Y = np.array(Y)

# X = np.array(X, dtype = np.float16)
# Y = np.array(Y)
# testX = np.array(testX, dtype = np.float16)
# testY = np.array(testY)

# print 'Length is', (X.shape)

# target = open('rawImgFlipTranslatedAll_' + str(split) + '_' + str(sizeDim) + '.p', 'wb')
# pickle.dump([X, testX, Y, testY],target)

# target = open('newTrainImgCPMB_' + str(split) + '_' + str(sizeDim) + '.p', 'wb')
# pickle.dump([X, testX, Y, testY],target)

# X, testX, Y, testY = pickle.load(open('trainImgCPMB' + str(sizeDim) +'.p', 'rb'))
# X, testX, Y, testY = pickle.load(open('trainImgAll' + str(sizeDim) +'.p', 'rb'))
# X, testX, Y, testY = pickle.load(open('trainImgCPMB' + str(sizeDim) +'.p', 'rb'))
# X, testX, Y, testY = pickle.load(open('trainImgCPMB_' + str(split) + '_' + str(sizeDim) + '.p', 'rb'))
# X, testX, Y, testY = pickle.load(open('rawImgFlipCPMB_' + str(split) + '_' + str(sizeDim) + '.p', 'rb'))
X, testX, Y, testY = pickle.load(open('rawImgFlipTranslatedAll_' + str(split) + '_' + str(sizeDim) + '.p', 'rb'))

#origX, origY = get_labeled_data('../data/mnist-train-images-idx3-ubyte.gz','../data/mnist-train-images-idx3-ubyte.gz')
#origTestX, origTestY = get_labeled_data('../data/mnist-t10k-images-idx3-ubyte.gz','../data/mnist-t10k-images-idx3-ubyte.gz')

Y = map(encode, Y)
testY = map(encode, testY)

# print origX.shape
# print origY.shape
# print origTestX.shape
# print origTestY.shape

# print 'Started HOG features'

origX, origY = [], []
origTestX, origTestY = [], []

pixCell = 16
cellBlock = 2
normalize = True

# # HOG features
# # Can try gamma normalization
# for i in range(0,len(X)):
# 	tmpX = hog(X[i], orientations=8, pixels_per_cell=(pixCell, pixCell), cells_per_block=(cellBlock, cellBlock), transform_sqrt = normalize)
# 	origX.append(tmpX)
# 	origY.append(Y[i])
# 	if (i%500==0):
# 		print i
# print

# for i in range(0,len(testX)):
# 	tmpX = hog(testX[i], orientations=8, pixels_per_cell=(pixCell, pixCell),cells_per_block=(cellBlock, cellBlock), transform_sqrt = normalize)
# 	origTestX.append(tmpX)
# 	origTestY.append(testY[i])
# 	if (i%500==0):
# 		print i
# print 

# X, Y = origX, origY
# testX, testY = origTestX, origTestY

# target = open('imgFlipAll_HOG_Norm_' + str(split) + '_' + str(sizeDim) + '_' +str(pixCell) + '_' + str(cellBlock) + '.p', 'wb')
# pickle.dump([X, testX, Y, testY],target)

# X, testX, Y, testY = pickle.load(open('imgFlipAll_HOG_Norm_' + str(split) + '_' + str(sizeDim) + '_' +str(pixCell) + '_' + str(cellBlock) + '.p', 'rb'))
# X, testX, Y, testY = pickle.load(open('imgCPMB_HOG_Norm_' + str(split) + '_' + str(sizeDim) + '_' +str(pixCell) + '_' + str(cellBlock) + '.p', 'rb'))

print 'Completed HOG features'

X = np.array(X, dtype = np.float16)
X = [x.flatten() for x in X]
Y = np.array(Y)
testX = np.array(testX, dtype = np.float16)
testX = [x.flatten() for x in testX]
testY = np.array(testY)

# targetName = 'Car'
# Y = transformLabel(Y, encode(targetName))
# testY = transformLabel(testY, encode(targetName))

# initVal, finVal = 'Bicycle', 'Rickshaw'
# Y = convertLabel(Y, encode(initVal), encode(finVal))
# testY = convertLabel(testY, encode(initVal), encode(finVal))

# initVal, finVal = 'Rickshaw', 'Motorcycle'
# Y = convertLabel(Y, encode(initVal), encode(finVal))
# testY = convertLabel(testY, encode(initVal), encode(finVal))

# initVal, finVal = 'Autorickshaw', 'Car'
# Y = convertLabel(Y, encode(initVal), encode(finVal))
# testY = convertLabel(testY, encode(initVal), encode(finVal))

# print X.shape
# print Y.shape
# print testX.shape
# print testY.shape

print "STARTING PCA"

pca = PCA(n_components = 50)
pca.fit(X)

X = pca.transform(X)

print "PCA COMPLETE"

# print X.shape
# print Y.shape

clf = LinearSVC()
# clf = SVC()
# clf = AdaBoostClassifier(RandomForestClassifier(n_estimators = 13), n_estimators = 31)
# clf = DecisionTreeClassifier()
# clf = RandomForestClassifier(n_estimators = 21)
clf.fit(X, Y)

# newtestX = pca.transform(testX) 
# testX = newtestX

print "Prediction starts for"
print dirPosList
pred = clf.predict(testX)
print (sklearn.metrics.classification_report(testY, pred, digits=4))
print sklearn.metrics.confusion_matrix(testY, pred)

joblib.dump(clf, 'svcNew4Class.pkl')
