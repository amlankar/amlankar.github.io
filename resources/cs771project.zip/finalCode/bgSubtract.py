from videoClass import *
import skimage.io as io
import pickle
import time
from subprocess import call

#COnvert images to uint8 to use in imshow and opencv cvtColor functions

#bg = GetBackground('test.mov')
bg = pickle.load(open( "tempBG.p", "rb"))

redFact = 0.75

#pickle.dump(bg, open("tempBG.p", "wb"))
#bg = pickle.load(open( "tempBG.p", "rb"))

graybg = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
    
graybg = cv2.resize(graybg, None, fx= redFact, fy=redFact)

io.imshow(graybg)
io.show()

#Method 1 : Simple Background subtraction

cap = VideoCapture('test.mov')
cap.open()

oldFrame = [graybg]*10

for i in range(50):
    ret, frame = cap.read()

cnt = 0

while True:
    ret, frame = cap.read()

    frame = cv2.resize(frame ,None, fx= redFact, fy=redFact)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    cv2.imshow('OrigGray',gray)
    cnt += 1

    tmpFrame = cv2.absdiff(gray, graybg)

    cv2.imwrite('tmpImage.jpg', gray)

    # tmpFrame = gray
    # tmpFrame = cv2.absdiff(gray, oldFrame)

    if (cnt%3 == 0):
        call(["alpr", "-n", "10", "--clock", "-d", "tmpImage.jpg"])

    # match(tmpFrame, oldFrame[0])

    # sift = cv2.SIFT(contrastThreshold = 0.1)
    # kp, sd = sift.detectAndCompute(tmpFrame,None)
    # cv2.imshow('frame',tmpFrame)
    # img=cv2.drawKeypoints(tmpFrame,kp)
    # cv2.imshow('SIFTframe',img)

    # print tmpFrame
    oldFrame[0:9] = oldFrame[1:]
    oldFrame[9] = tmpFrame
    # frame[frame<0] = 0
    # tmpFrame = tmpFrame.astype(np.uint8)
    ret, tmpFrame = cv2.threshold(tmpFrame, 50, 255, cv2.THRESH_BINARY)			#THRESH_TOZERO, THRESH_BINARY and the INV possible options
    #color = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    cv2.imshow('frame',tmpFrame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()