import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import pickle
from mpl_toolkits.mplot3d import Axes3D

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import scale
from sklearn.cluster import MeanShift, estimate_bandwidth


dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle', 'Autorickshaw', 'Rickshaw']

# names = ['Not Car', 'Car', 'Not Car']

def ClusterPlot (data, label, dim=2):
	###############################################################################
	# Visualize the results on PCA-reduced contextList

	print "STARTED REDUCING"

	if (dim == 3):

		reduced_data = PCA(n_components=3).fit_transform(data)

		print "DATA REDUCED"

		Z = np.array(label)

		fig = plt.figure(1)

		ax = Axes3D(fig)

		x_min, x_max = reduced_data[:, 0].min(), reduced_data[:, 0].max()
		y_min, y_max = reduced_data[:, 1].min(), reduced_data[:, 1].max()
		z_min, z_max = reduced_data[:, 2].min(), reduced_data[:, 2].max()
		
		x, y, z = np.array(reduced_data[:, 0]), np.array(reduced_data[:, 1]), np.array(reduced_data[:, 2])
		ax.scatter(x, y, z, c = Z, alpha = 0.5)

		# plt.title('Cluster Plots (Reuction with PCA)')
		# plt.xlim(x_min, x_max)
		# plt.ylim(y_min, y_max)
		# plt.zlim(z_min, z_max)
		# plt.xticks(())
		# plt.yticks(())
		# plt.zticks(())
		plt.show()

	else:
		
		reduced_data = PCA(n_components=2).fit_transform(data)

		print "DATA REDUCED"
		X =reduced_data

		Z = np.array(label)

		plt.figure(1)

		x_min, x_max = reduced_data[:, 0].min(), reduced_data[:, 0].max()
		y_min, y_max = reduced_data[:, 1].min(), reduced_data[:, 1].max()
		
		x, y = np.array(reduced_data[:, 0]), np.array(reduced_data[:, 1])
		plt.scatter(x, y, c = Z, alpha = 0.5)

		for lab in list(set(label)):
			lab = int(lab)
			plt.text(X[label == lab, 0].mean(), X[label == lab, 1].mean() + 1.5, names[lab],
					  horizontalalignment='center', bbox=dict(alpha=.5, edgecolor='w', facecolor='w'))


		plt.title('Cluster Plots (Reduction with PCA)')
		plt.xlim(x_min, x_max)
		plt.ylim(y_min, y_max)
		plt.xticks(())
		plt.yticks(())
		plt.show()



def getColor(label):
	tmpList = ['Car', 'Person', 'Motorcycle', 'Bicycle']
	colorList = ['r', 'b', 'g', 'y']
	if (type(label) is np.int32):
		# return colorList[label]
		return label	
	# return colorList[tmpList.index(val)]
	return label

def PlotTSNE (data, label):										#Takes the data and the labels
	# Visualize the results on TSNE reduced data

	print "BUSY IN TSNE"

	model = TSNE(n_components=2)
	reduced_data = model.fit_transform(data)

	X = reduced_data
	print "DATA REDUCED"

	Z = np.array(label)

	plt.figure(1)
	
	x_min, x_max = reduced_data[:, 0].min(), reduced_data[:, 0].max()
	y_min, y_max = reduced_data[:, 1].min(), reduced_data[:, 1].max()
	# z_min, z_max = reduced_data[:, 2].min(), reduced_data[:, 2].max()
	
	x, y = np.array(reduced_data[:, 0]), np.array(reduced_data[:, 1])
	plt.scatter(x, y, c = Z, alpha = 0.5)

	for lab in set(label):
			lab = int(lab)
			plt.text(X[label == lab, 0].mean(), X[label == lab, 1].mean() + 1.5, dirPosList[lab],
					  horizontalalignment='center', bbox=dict(alpha=.5, edgecolor='w', facecolor='w'))

	# plt.title('Cluster Plots (Reuction with TSNE)')
	# plt.xlim(x_min, x_max)
	# plt.ylim(y_min, y_max)
	# plt.xticks(())
	# plt.yticks(())
	plt.show()


sizeDim = 100
split = (0.8)
pixCell = 16
cellBlock = 2
normalize = True

# dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle', 'Number-plate', 'Autorickshaw', 'Rickshaw']
# dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle']
# dirPosList = ['Car', 'Person']

def encode(val):
	if (val not in dirPosList):
		return val
	return dirPosList.index(val)

def transformLabel(Y, target):
	Y[Y != target] = -1
	Y[Y == target] = 1
	return Y

def convertLabel(Y, initVal, finalVal):
	# Transform initVal to finalVal
	Y[Y == initVal] = finalVal
	return Y

def removeLabel(Y, target):
	return Y[Y != target]

def main():
	# X, testX, Y, testY = pickle.load(open('rawImgCPMB_HOG_Norm_' + str(split) + '_' + str(sizeDim) + '_' +str(pixCell) + '_' + str(cellBlock) + '.p', 'rb'))
	# X, testX, Y, testY = pickle.load(open('rawImgFlipCPMB_' + str(split) + '_' + str(sizeDim) + '.p', 'rb'))
	X, testX, Y, testY = pickle.load(open('rawImgFlipTranslatedAll_' + str(split) + '_' + str(sizeDim) + '.p', 'rb'))

	X = list(X)
	Y = list(Y)
	testX = list(testX)
	testY = list(testY)

	X.extend(testX)
	Y.extend(testY)

	print set(Y)

	Y = map(encode, Y)
	X = np.array(X, dtype = np.float16)
	Y = np.array(Y)

	# targetName = 'Car'
	# Y = transformLabel(Y, encode(targetName))

	ignoreList = [encode(x) for x in ['Person']]

	initVal, finVal = 'Bicycle', 'Rickshaw'
	Y = convertLabel(Y, encode(initVal), encode(finVal))

	print Y, max(Y), min(Y)

	# print np.min(Y), np.max(Y)

	tmpList = {}

	for i in range(len(X)):
		if (Y[i] in ignoreList):
			continue
		if (Y[i] not in tmpList):
			tmpList[Y[i]] = []
		tmpList[Y[i]].append(X[i].flatten())

	print tmpList.keys()
	newX = []
	newY = []

	for k in tmpList.keys():
		tmpList[k] = tmpList[k][:1000]
		newX.extend(tmpList[k])
		newY.extend([encode(k)]*len(tmpList[k]))
		print k, len(tmpList[k])

	# print newX
	newX = np.array(newX, dtype = np.float16)
	newY = np.array(newY, dtype = np.float16)

	print 'COMPLETED LOADING THE RAW IMAGES'
	print newX.shape
	print newY.shape
	# tmpX = []
	# for x in X:
	# 	tmpX.append(x.flatten())
	# tmpX = np.array(tmpX)
	# print tmpX.shape

	PlotTSNE(newX, newY)
	# ClusterPlot(newX, newY, 2)

main()


