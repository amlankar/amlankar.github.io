#!/bin/python
#-*- coding: UTF-8 -*-

import codecs
import re

files = ['hindi-movie.pos.unedited','hindi-movie.neg.unedited']

for file in files:
    file_to_write = codecs.open(file[:-9],"wb",encoding="utf-8")
    lines = []
    f=codecs.open(file,encoding='utf-8')
    for line in f:
	line = line.replace(u"।",'\n')
	lines.append(line)
    for line in lines:
	line = line.rstrip()
	if line != '':
	    file_to_write.write(line)
