#Deep Learning for Document Classification 

Requirements for code:

* Python 2.7
* Numpy
* Scipy
* Scikit-Learn
* [Theano](http://deeplearning.net/software/theano)

####Folders not included in repository:
#####skip-thoughts/
Contains [code](https://github.com/ryankiros/skip-thoughts) for the paper on Skip-Thought vectors. Also includes the data files required for the model.

#####word2vec/
Contains [code](https://code.google.com/p/word2vec/) for the Word2Vec implementation by Tomas Mikolov et al. Also includes the pre-trained weights on the Google-News dataset.

Running process-data.py /path/to/word2vecfile/ produces a file named mr-{language}.p depending on which file was fed to process data.py
To change the file that it reads, modify the code in the __main__ function in the file to make it point to the hindi/english files.
Once the pickle files have been made, run python conv_net_sentence.py -nonstatic -word2vec to run the model whose results have been
shown. To run the model where the word vectors are not fine-tuned, use -static instead of -nonstatic.

This will train the ConvNet for 10 epochs and report the 10 fold CV accuracy. Additionally, it will store a pickle file(words-{language}.p) containing the
fine-tuned word vectors for the model that achieved maximum validation accuracy. For hindi, change the name of the saved pickle file in the
conv_net_sentence code. 

Run python nearest-neighbour.py to start an interactive program that will ask for words and output the nearest neighbours in the old word vectors
and in the new fine tuned word vectors.
