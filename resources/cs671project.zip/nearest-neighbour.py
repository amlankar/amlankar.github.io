import sys
import cPickle
from scipy.spatial.distance import cosine

if len(sys.argv) != 2:
    print "Usage: python nearest-neighbour.py -english/hindi"
    sys.exit(0)

x = sys.argv[1]

if x == '-english':
    file = 'words-english.p'
elif x == '-hindi':
    file = 'words-hindi.p'

print "Loading data..."
W2 = cPickle.load(open(file,'rb'))
x = cPickle.load(open("mr"+file[5:],"rb"))
_ ,W3,_,word_idx_map,vocab = x[0], x[1], x[2], x[3], x[4]
print "Data loaded!"
print "Usage:"
print "Enter a word to get it's old and new nearest neighbours. Enter q to quit"
W = W2[0].get_value()

while(1):
    print "Enter a word: "
    distance_new = []
    distance_old = []
    inp_word = raw_input()

    if inp_word not in vocab:
	print "Word not found in Vocab!"
	continue

    if inp_word == 'q':
	print "Exiting!"
	break

    for word in word_idx_map:
	distance_new.append([word,cosine(W[word_idx_map[inp_word]],W[word_idx_map[word]])])
	distance_old.append([word,cosine(W3[word_idx_map[inp_word]],W3[word_idx_map[word]])])

    distance_new.sort(key=lambda tuple: tuple[1])
    distance_old.sort(key=lambda tuple: tuple[1])
    print "----------Old-Distances----------"
    print distance_old[1:5]

    print "----------New-Distances----------"
    print distance_new[1:5]
